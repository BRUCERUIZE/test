<template>
    <!-- 组件的结构 -->
    <div class="demo">
        <h2>学校名称:{{ schoolName }}</h2>
        <h2>学校地址:{{ address }}</h2>
        <button @click="showName">点我提示学校名</button>
    </div>
</template>


<script>
    //组件交互相关的代码
    //export default school 分别暴露
    export default {
    name: 'School', //开发者工具最终呈现的名字为School
    data(){
      return {
        name:'武汉科技大学',
        address: '武汉'
      }
    },
    methods:{
      showName(){
        alert(this.name);
      }
    }
  };

    // const school = Vue.extend({
    //     data(){
    //         return {
    //             schoolName: '武汉科技大学', 
    //             address:'武汉'
    //         }
    //     },
    //     methods:{
    //         showName(){
    //             alert(this.schoolName)
    //         },
    //     }
    // });
    // export default school


    //统一暴露
    // export { school };
    //默认暴露
    // export default school 
</script>

<style>
    /* 组件的样式 */
    .demo{
        background-color: orange;
    }


</style>

